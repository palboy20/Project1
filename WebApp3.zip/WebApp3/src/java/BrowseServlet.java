import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Blob;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = {"/browse"})
public class BrowseServlet extends HttpServlet 
{

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        String email=req.getParameter("txt3");
        String gender=req.getAttribute("gender").toString();
        String b=req.getAttribute("img").toString();
        //String gender=req.getParameter("gender");
        PrintWriter pw=resp.getWriter();
        pw.println("<html>");
        pw.println("<link href='kajol.css' rel=stylesheet>");
        pw.println("<center>");
        pw.println("<form action='upload?gender="+gender+"&txt3="+email+"' enctype='multipart/form-data' method=post>");
        pw.println("<table style='margin-top: 50px;'>");
        pw.println("<tr>");
        pw.println("<td rowspan=2>");
        if(b.equals("N")){
            pw.println("<img src='"+gender+".png' width=150 height=150>");
        }else{
            pw.println("<img src='http://localhost:7070/WebApp3/img?email="+email+"' width=150 height=150>");
        }
        pw.println("</td>");
        pw.println("<td>");
        pw.println("<tr>");
        pw.println("<td><input type=file name=file></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        pw.println("<td><input type=submit value='UPLOAD' name=sbt class='btn'>&nbsp;&nbsp;&nbsp;<input type=submit value='NEXT' class='btn' name=sbt></td>");
        pw.println("</tr>");
        pw.println("</td>");
        pw.println("</tr>");
        pw.println("</table>");
        pw.println("</center>");
        pw.println("</html>");
    }
    
}
