import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = {"/signup"})
public class SignupServlet extends HttpServlet 
{
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        try{
        String s1=req.getParameter("txt1");
        String s2=req.getParameter("txt2");
        String s3=req.getParameter("txt3");
        String s4=req.getParameter("txt5");
        String s5=req.getParameter("rad");
        String s6=req.getParameter("cnt");
        Class.forName("com.mysql.jdbc.Driver");
        Connection c=DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/photo_editor",
                "root","123");
        Statement st=c.createStatement();
        otp=getOTP();
        st.executeUpdate("insert into users(f_name,l_name,email,password,gender,country,verfied,otp) values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','N','"+otp+"')");
        sendMail(s3);
        PrintWriter pw=resp.getWriter();
        pw.println("Values Saved");
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
    int otp;
    public int getOTP()
    {
        int num=(int)(1000000*Math.random());
        if(num<100000){
            getOTP();
        }
        return num; 
    }
    public void sendMail(String email)
    {
        try{
        Properties props=new Properties();
        props.put("mail.smtp.host", 
                "smtp.gmail.com");
        props.put("mail.smtp.user", "zabaish012345");
        props.put("mail.smtp.password", "v@r@rgs@123");
        props.put("mail.smtp.port", "465");
        props.put("mail.smtps.auth", true);
        Session ses=Session.getDefaultInstance(props);
        MimeMessage message=new MimeMessage(ses);
        message.setSubject("Confirmation mail from Photo Editor Team");
        message.setSender(new InternetAddress(
                "zabaish12345@gmail.com"));
        message.setRecipient(Message.RecipientType.TO,
                new InternetAddress(email));
        message.setContent("Dear Sir/Ma'am,<br><br>Greetings from photo editor team!!!!<br><br> Thanks for choosing photo editor for editing photos.We promise you to give best functions for editing photos.<br><br><span style='font-size: 25px'>"+otp+"</span><br><br>Please click or copy paste link given below and complete registration process <br><br>http://localhost:7070/WebApp3/verify?email="+email+"<br>Happy to help you<br><br>Regards,<br>Technical Team", 
                "text/html");
        Transport trans=ses.getTransport("smtps");
        trans.connect("smtp.gmail.com", 
                "zabaish12345","v@r@rgs@123");
        trans.sendMessage(message,
                message.getAllRecipients());
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
 