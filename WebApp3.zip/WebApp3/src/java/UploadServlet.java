
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.sql.rowset.serial.SerialBlob;

@MultipartConfig(maxFileSize = 2 * 1024 * 1024)
@WebServlet(urlPatterns = {"/upload"})
public class UploadServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sbt = "UPLOAD";//req.getParameter("sbt");
        if (sbt.equals("UPLOAD")) {
            try {
                String gender = "male";//req.getParameter("gender");
                String email = "shyamlala@gmail.com";//req.getParameter("txt3");
                //Part p = req.getPart("file");
                //InputStream in = p.getInputStream();
                InputStream in = req.getInputStream();
                int totalBytes = req.getContentLength();
                byte b[] = new byte[totalBytes];
                int readBytes = 0, bytes = 0;
                while (readBytes < totalBytes) {
                    bytes = in.read(b, readBytes, totalBytes);
                    readBytes += bytes;
                }
                String file=new String(b);
                String contentTpe = req.getContentType();
                int boundryL = contentTpe.indexOf("=");
                String boundry = contentTpe.substring(boundryL + 1);
                int pos = file.indexOf("filename=\"") + 10;
                pos = file.indexOf('\n', pos) + 1;
                pos = file.indexOf('\n', pos) + 1;
                pos = file.indexOf('\n', pos) + 1;
                int end = file.indexOf(boundry, pos) - 4;
                ByteArrayInputStream bin=new ByteArrayInputStream(b, pos, (end-pos));
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection c = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/photo_editor",
                        "root", "123");
                PreparedStatement st = c.
                        prepareStatement(
                                "update users set profilepic=? where email=?");

                st.setBinaryStream(1,bin);
                st.setString(2, email);
                st.executeUpdate();
                st.close();
                c.close();
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/browse");
                req.setAttribute("gender", gender);
                req.setAttribute("img", "Y");
                rd.forward(req, resp);
            } catch (Exception e) {
                System.out.println(e);
            }
        } else if (sbt.equals("NEXT")) {
            resp.sendRedirect("welcome");

        }
    }
}
