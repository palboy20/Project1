import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req,
            HttpServletResponse resp) throws ServletException, IOException {
        try {
            String s1 = req.getParameter("txt3");
            String s2 = req.getParameter("txt4");
            Class.forName("com.mysql.jdbc.Driver");
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/photo_editor","root","123");
            //Statement st = c.createStatement();
            PreparedStatement pst=c.prepareStatement("select * from users where email=? and password=?");
            pst.setString(1, s1);
            pst.setString(2, s2);
            //ResultSet rs = st.executeQuery("select verfied,f_name,l_name,gender from users where email='"
            //        + s1 + "' and password='" + s2 + "'");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                String v = rs.getString("verfied");
                String gender = rs.getString("gender");
                String fname = rs.getString("f_name");
                String lname = rs.getString("l_name");
                Cookie ck=new Cookie("ckname", fname+" "+lname);
                resp.addCookie(ck);
                Blob b=rs.getBlob("profilepic");
                String isPicAvailable;
                if(b==null)
                    isPicAvailable="N";
                else
                    isPicAvailable="Y";
                if (v.equals("N")) {
                    resp.sendRedirect("loginver.html");
                } else {
                    //resp.sendRedirect("browse?email="+s1+"&gender="+gender);
                    if(b==null){
                    RequestDispatcher rd=
                            getServletContext().
                         getRequestDispatcher("/browse");
                    req.setAttribute("gender", gender);
                    req.setAttribute("img", isPicAvailable);
                    rd.forward(req, resp);
                    }else{
                        HttpSession ses=req.getSession();
                        ses.setAttribute("email", s1);
                        resp.sendRedirect("welcome?name="+fname+" "+lname);
                    }
                }
            } else {
                resp.sendRedirect("loginerr.html");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
