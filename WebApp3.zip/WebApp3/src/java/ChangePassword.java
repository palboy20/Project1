import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = {"/change"})
public class ChangePassword extends HttpServlet 
{
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        PrintWriter pw=resp.getWriter();
        pw.println("<html>");
        RequestDispatcher rd1=getServletContext().getRequestDispatcher("/head");
        rd1.include(req, resp);
        pw.println("<div class=content>");
        RequestDispatcher rd2=getServletContext().getRequestDispatcher("/nav");
        rd2.include(req, resp);
        pw.println("<div class=\"frm\">");
        pw.println("<form action='match'>");
        pw.println("<table>");
        pw.println("<tr>");
        pw.println("<td>Old Password</td>");
        pw.println("<td><input type=password name=op class=tf></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        pw.println("<td>New Password</td>");
        pw.println("<td><input type=password name=np class=tf></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        pw.println("<td>Confirm Password</td>");
        pw.println("<td><input type=password name=cp class=tf></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        pw.println("<td colspan=2>Enter Captcha Text </td>");
        pw.println("</tr>");
        pw.println("<tr>");
        InetAddress address=
                InetAddress.getLocalHost();
        String ip=address.getHostAddress();
        pw.println("<td colspan=2><img src='http://"+ip+":7070/WebApp3/captchaImage'></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        pw.println("<td colspan=2><input type=text name=cap class=tf></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        pw.println("<td colspan=2><input type=submit name=sbt value=SUBMIT class=btn></td>");
        pw.println("</tr>");
        pw.println("<tr>");
        String s=req.getParameter("err");
        if(s!=null&&s.equals("A")){
        pw.println("<td colspan=2 style='color:red'>");
        pw.println("Password Changed Successfully");
        pw.println("</td>");
        }else if(s!=null&&s.equals("B")){
        pw.println("<td colspan=2 style='color:red'>");
        pw.println("Passwords mismatched");
        pw.println("</td>");
        }else if(s!=null&&s.equals("C")){
        pw.println("<td colspan=2 style='color:red'>");
        pw.println("Invalid Captcha Text");
        pw.println("</td>");
        }
        pw.println("</tr>");
        
        pw.println("</table>");
        pw.println("</form>");
        pw.println("</div>");
        pw.println("</div>");
        pw.println("</html>");
    } 
}


